var voMetrics = function (player, scope, playerLib) {
  this.player_ = player;
  this.curVideoTrack_;
  this.init(scope, playerLib);
};

voMetrics.prototype = {
  init: function(scope, playerLib) {
    var self = this;
    this.player_.addEventListener(playerLib.events.VO_OSMP_SRC_ADAPTIVE_STREAMING_INFO_EVENT_BITRATE_CHANGE,
      function(e) {
        if (e.mediaType === 'video') {
          self.curVideoTrack_ = self.player_.getCurrentQualityLevel();
        }
      },
      scope);
  },
  updateMetrics: function (type) {
    var bufferLevel = this.player_.getValidBufferDuration(type);
    var liveLatency = 0;
    if (this.player_.isLive()) {
      liveLatency = this.player_.getCurrentLiveLatency();
    }
    var bitrate;
    if ('video' === type) {
      bitrate = this.curVideoTrack_ && this.curVideoTrack_.bandwidth ? Math.round(this.curVideoTrack_.bandwidth / 1000) : 0;
    }
    return {
      bufferLevel: bufferLevel ? bufferLevel : 0,
      liveLatency: liveLatency,
      bitrate: bitrate
    };
  }
};

var voChartData = function (metrics) {
  this.metrics_ = metrics;
  this.sessionStartTime_;
  this.maxPointsToChart_ = 30;
  this.maxChartableItems_ = 5;
  this.reset();
};

voChartData.prototype = {
  reset: function() {
    var self = this;
    this.chartState_ = {
      video:{
        buffer:  {data: [], selected: true, color: '#30A33E', label: 'Video Buffer Level'},
        bitrate: {data: [], selected: true, color: '#00589d', label: 'Video Bitrate (kbps)'},
        liveLatency: {data: [], selected: false, color: '#FF6347', label: 'Video Latency (ms)'}
      }
    };
    this.chartOptions_ = {
      legend: {
          position: "nw",
          labelBoxBorderColor: '#ffffff',
          placement: 'outsideGrid',
          container: '#linelegend-wrapper',
          labelFormatter: function (label, series) {
              return '<div  style="cursor: pointer;" id="' + series.type + '.' + series.id + '" onclick="legendLabelClickHandler(this)">' + label + '</div>';
          }
      },
      series: {
          lines: {
              show: true,
              lineWidth: 2,
      
              shadowSize: 5,
              steps: false,
              fill: false,
          },
          points: {
              radius: 4,
              fill: true,
              show: true
          }
      },
      grid: {
          show: true,
          clickable: false,
          autoHighlight: true,
          borderColor: '#D9D9D9',
          color: 'black',
          borderWidth: 3,
          mouseActiveRadius: 20,
          axisMargin: 20,
      },
      axisLabels: {
          position: 'right'
      },
      xaxis: {
          tickFormatter: function tickFormatter(value) {
              return self.convertToTimeCode(value);
          },
          tickDecimals: 0,
          color: '#D9D9D9',
          alignTicksWithAxis: 1
      },
      yaxis: {
          min: 0,
          tickLength: 0,
          tickDecimals: 0,
          position: 'left',
          axisLabelPadding: 5,
          color: '#D9D9D9',
          axisLabelUseCanvas: true,
          axisLabelFontSizePixels: 12
      },
      yaxes: []
    };
    this.chartData_ = [];
  },

  clearChartData: function () {
    for (var key in this.chartState_) {
        for (var i in this.chartState_[key]) {
            this.chartState_[key][i].data.length = 0;
        }
    }
  },

  plotPoint: function (name, type, value, time) {
    var specificChart = this.chartState_[type];
    if (specificChart && specificChart[name] && specificChart[name].data) {
        var data = specificChart[name].data;
        data.push([time, value]);
        if (data.length > this.maxPointsToChart_) {
            data.splice(0, 1);
        }
    }
  },

  selectChartByName: function (id, type, value) {
    this.chartState_[type][id].selected = value;
    this.enableChartByName(id, type);
  },

  enableChartByName: function (id, type) {
      // enable stat item
      if (this.chartState_[type][id].selected) {
          // block stat item if too many already.
          if (this.chartData_.length === this.maxChartableItems_) {
              alert('You have selected too many items to chart simultaneously. Max allowd is ' + this.maxChartableItems_ + '. Please unselect another item first, then reselected ' + this.chartState_[type][id].label);
              this.chartState_[type][id].selected = false;
              return;
          }

          var data = {
              id: id,
              data: this.chartState_[type][id].data,
              label: this.chartState_[type][id].label,
              color: this.chartState_[type][id].color,
              yaxis: this.chartData_.length + 1,
              type: type
          };
          this.chartData_.push(data);
          this.chartOptions_.yaxes.push({
              axisLabel: data.label
          });
      } else { //remove stat item from charts
          for (var i = 0; i < this.chartData_.length; i++) {
              if (this.chartData_[i].id === id && this.chartData_[i].type === type) {
                  this.chartData_.splice(i, 1);
                  this.chartOptions_.yaxes.splice(i, 1);
              }
              if (this.chartData_.length > i) {
                  this.chartData_[i].yaxis = i + 1;
              }
          }
      }

      this.chartOptions_.legend.noColumns = Math.min(this.chartData_.length, 5);
  },

  initSession: function () {
      this.clearChartData();
      this.reset();
      this.sessionStartTime_ = new Date().getTime() / 1000;
  },

  initChartingByMediaType: function (type) {
    var arr = this.chartState_[type];
    for (var key in arr) {
      var obj = arr[key];
      if (obj.selected) {
          this.enableChartByName(key, type);
      }
    }
  },

  initChartDataSession: function() {
    this.initSession();
    this.initChartingByMediaType('video');
    var ret = this.getChartInfo();
    return ret;
  },

  updateChartData: function (type) {
    var ret;
    var metrics = this.metrics_ ? this.metrics_.updateMetrics(type) : null;
    if (!metrics) {
      return null;
    }
    this[type + 'BufferLength'] = metrics.bufferLevel;
    this[type + 'Bitrate'] = metrics.bitrate;
    this[type + 'Latency'] = metrics.liveLatency;
    var time = this.getTimeForPlot();
    this.plotPoint('buffer', type, metrics.bufferLevel, time);
    this.plotPoint('bitrate', type, metrics.bitrate, time);
    this.plotPoint('liveLatency', type, metrics.liveLatency, time);
    ret = this.getChartInfo();
    return ret;
  },

  getChartInfo: function () {
     return {data: this.chartData_, options: this.chartOptions_};
  },

  getTimeForPlot: function () {
    var now = new Date().getTime() / 1000;
    return Math.max(now - this.sessionStartTime_, 0);
  },

  convertToTimeCode: function (value) {
    value = Math.max(value, 0);

    var h = Math.floor(value / 3600);
    var m = Math.floor((value % 3600) / 60);
    var s = Math.floor((value % 3600) % 60);
    return (h === 0 ? '' : (h < 10 ? '0' + h.toString() + ':' : h.toString() + ':')) + (m < 10 ? '0' + m.toString() : m.toString()) + ':' + (s < 10 ? '0' + s.toString() : s.toString());
  }
};

var voLineChart = function () {
  this.chartCount_ = 0;
  this.chartInfo_;
  this.metricsTimer_= null;
  this.updateMetricsInterval_ = 1000;
  this.chartData_;
  this.chartEnabled_ = true;
  this.idBtnChartDataClear_;
  this.idBtnChartDataEnable_;
  this.hasActive_ = false;
};

/////////////////////////////////////////////////////////////////////////
voLineChart.prototype = {
  init: function(player, scope, playerLib) {
    this.chartData_ = new voChartData(new voMetrics(player, scope, playerLib));
    this.player_ = player;
    this.initBtn();
    this.registerEvent(scope, playerLib);
  },
  reset: function() {
    this.stopUpdateInterval();
    this.chartCount_ = 0;
    this.chartInfo_ = null;
    this.chartEnabled_ = true;
  },
  registerEvent: function(scope, playerLib) {
    this.player_.addEventListener(playerLib.events.VO_OSMP_SRC_CB_OPEN_FINISHED, this.onPlayerOpenFinished.bind(this), scope);
    // player.addEventListener(playerLib.events.VO_OSMP_CB_PLAY_COMPLETE,
    //   () => {
    //     this.stopUpdateInterval();
    //   },
    //   scope);
    this.player_.addEventListener(playerLib.events.VO_OSMP_SRC_CB_CLOSED, this.onPlayerClosed.bind(this), scope);
  },
  initBtn: function() {
    // chart data
    this.idBtnChartDataClear_ = document.getElementById('idBtnChartClear');
    this.idBtnChartDataEnable_ = document.getElementById('idBtnChartEnable');
    this.idBtnChartDataEnable_.textContent = 'Disable';
    var self = this;
    this.idBtnChartDataClear_.addEventListener('click', function() {
      self.chartData_.clearChartData();
      self.chartInfo_ =  self.chartData_.getChartInfo();
      self.updateChartData();
    });
    this.idBtnChartDataEnable_.addEventListener('click', function() {
      self.chartEnabled_ = !self.chartEnabled_;
      self.idBtnChartDataEnable_.textContent = self.chartEnabled_ ? 'Disable' : 'Enable';
      $('#linechart-wrapper').fadeTo(500, self.chartEnabled_ ? 1 : 0.3);
    });
  },

  onPlayerOpenFinished: function(playr) {
    this.initChartDataSession();
    this.stopUpdateInterval();
    this.startUpdateInterval();
    if (this.player_.isLive())
    this.selectChartByName('liveLatency', 'video', true);
  },

  onPlayerClosed: function() {
    this.stopUpdateInterval();
    this.initChartDataSession();
  },

  setActive: function(value) {
    this.hasActive_ = !this.hasActive_ ? value : this.hasActive_;
  },

  startUpdateInterval: function () {
    this.chartCount_ = 0;
    var self = this;
    this.metricsTimer_ = setInterval(function () {
      if (self.chartCount_ % 2 === 0) {
        if (self.chartEnabled_) {
          var ret = self.chartData_.updateChartData('video');
          self.chartInfo_ = ret ? ret : self.chartInfo_;
        }
        self.updateChartData();
      }
      self.chartCount_++;
    }, this.updateMetricsInterval_);
  },
  stopUpdateInterval: function () {
    if (this.metricsTimer_) {
        clearInterval(this.metricsTimer_);
        this.metricsTimer_ = null;
    }
  },
  updateChartData: function() {
    if (!this.hasActive_) {
      return;
    }
    if (this.chartInfo_) {
      $.plot($("#linechart-inventory"), this.chartInfo_.data, this.chartInfo_.options);
    }
  },
  initChartDataSession: function() {
    this.chartInfo_ = this.chartData_.initChartDataSession();
    this.updateChartData();
    this.reset();
  },
  selectChartByName: function(id, type, value) {
    this.chartData_.selectChartByName(id, type, value);
  }
};