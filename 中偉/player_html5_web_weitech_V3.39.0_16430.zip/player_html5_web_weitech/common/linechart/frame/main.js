'use strict';
var lineChart_;
function createLineChart(player, playerContext, playerLib) {
  lineChart_ = new voLineChart();
  lineChart_.init(player, playerContext, playerLib);
}