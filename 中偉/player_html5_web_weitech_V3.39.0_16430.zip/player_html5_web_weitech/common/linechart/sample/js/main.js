'use strict';
var player_;
var playerContainer_;
var playerContext_ = {
  flag: 'main'
};
var idBtnLoad_;
var cfg_ = {
  width: '100%',
  height: '100%',
  playback: {
    autoPlay: true
  },
  cast: {
    receiverAppId: 'B5BCD208' //VisualOn default customer receiver
  },
  advanced: {
    segmentDownloadRetryCount: 3
  },
  logs: {
    logToConsole: true
  }
};

function convertToTimeCode(value) {
    value = Math.max(value, 0);

    let h = Math.floor(value / 3600);
    let m = Math.floor((value % 3600) / 60);
    let s = Math.floor((value % 3600) % 60);
    return (h === 0 ? '' : (h < 10 ? '0' + h.toString() + ':' : h.toString() + ':')) + (m < 10 ? '0' + m.toString() : m.toString()) + ':' + (s < 10 ? '0' + s.toString() : s.toString());
}

function onBtnLoad(e) {
  initChartData();
  var sourceCfg_ = {
    links: [{
      uri: 'https://livesim.dashif.org/dash/vod/testpic_2s/multi_subs.mpd',
      type: 'dash'
    }]
  };
  player_.open(sourceCfg_);
}

function initPlayer() {
  playerContainer_ = document.getElementById('player-container');
  // build player
  player_ = new voPlayer.Player(playerContainer_);
  player_.init(cfg_);

  // attach ui engine
  createLineChart();
}

function initTabAssets() {
  idBtnLoad_ = document.getElementById('idBtnLoad');
  initLoadButton();
}

function createLineChart() {
  if ('undefined' !== typeof(frameLineChart) && frameLineChart.window && frameLineChart.window.createLineChart) {
    frameLineChart.window.createLineChart(player_, playerContext_, voPlayer);
  }
}

function initChartData()
{
  if ('undefined' !== typeof(frameLineChart) && frameLineChart.window && frameLineChart.window.lineChart_) {
    frameLineChart.window.lineChart_.initChartDataSession();
  }
}


function initLoadButton() {
  idBtnLoad_.addEventListener('click', onBtnLoad);
}

window.onload = function () {
  initTabAssets();
  initPlayer();
};